/* Luu y: doi voi bai tap nay,
   sinh vien khong duoc thay doi khai bao ham
   sinh vien phai cai dat ham dua tren khai bao ham duoc cung cap
*/
#include <iostream>
#include <cstdlib>
#include <time.h>

using namespace std;

struct thoigian
{
	int gio;
	int phut;
	int giay;
	struct thoigian * tiepTheo;
};
typedef struct thoigian ThoiGian;
typedef ThoiGian * ThoiGianPtr;

ThoiGianPtr taoNutMoi();

void quyChuanThoiGian(ThoiGianPtr);

void inThoiGian(const ThoiGianPtr);

bool soSanhThoiGianLonHon(const ThoiGianPtr, const ThoiGianPtr);
bool soSanhThoiGianNhoHon(const ThoiGianPtr, const ThoiGianPtr);
bool soSanhThoiGianBang(const ThoiGianPtr, const ThoiGianPtr);
bool soSanhThoiGianKhac(const ThoiGianPtr, const ThoiGianPtr);

void chenNut(ThoiGianPtr &dau, ThoiGianPtr nutChen);

ThoiGianPtr gopDSLK(ThoiGianPtr &dau1, ThoiGianPtr &dau2);

void inDanhSachLienKet(const ThoiGianPtr dau);

int main()
{
	srand(time(0));
	int i, N1, N2;
	ThoiGianPtr dau1, dau2, tg3;
	dau1 = taoNutMoi();
	dau2 = taoNutMoi();
	cout<<"Nhap vao so luong cho day 1 : ";
	cin>>N1;
	for (i=1;i<N1;i++)
	{
        tg3 = taoNutMoi();
        chenNut(dau1, tg3);
    }
    cout<<"Nhap vao so luong cho day 2 : ";
    cin>>N2;
    for (i=1;i<N2;i++)
    {
        tg3 = taoNutMoi();
        chenNut(dau2, tg3);
    }
    cout<<"Danh sach 1 : \n";
	inDanhSachLienKet(dau1);
	cout<<"Danh sach 2 : \n";
	inDanhSachLienKet(dau2);

	// gop 2 danh sach tren thanh mot danh sach
	ThoiGianPtr dau = gopDSLK(dau1, dau2);
	cout<<"Danh sach gop : \n";
	inDanhSachLienKet(dau);

    cout<<"Danh sach lien ket 1 : \n";
    inDanhSachLienKet(dau1);

    cout<<"Danh sach lien ket 2 : \n";
    inDanhSachLienKet(dau2);

    free(dau1);
    free(dau2);
    free(dau);
    free(tg3);
	system("PAUSE");
	return EXIT_SUCCESS;
}

ThoiGianPtr taoNutMoi()
{
	ThoiGianPtr tg = new ThoiGian;
	tg->gio = rand()%24 + 1;
	tg->phut = rand()%60 + 1;
	tg->giay = rand()%60 + 1;
	tg->tiepTheo = NULL;
	quyChuanThoiGian(tg);
	return tg;
}

void quyChuanThoiGian(ThoiGianPtr tg)
{
    if (tg->giay>59)
    {
        tg->giay = tg->giay - 60;
        tg->phut += 1;
    }
    if (tg->phut>59)
    {
        tg->phut = tg->phut - 60;
        tg->gio += 1;
    }
    if (tg->gio>23)
    {
        tg->gio = tg->gio - 24;
    }

    if (tg->giay<0)
    {
        tg->giay = tg->giay + 60;
        tg->phut -= 1;
    }
    if (tg->phut<0)
    {
        tg->phut = tg->phut + 60;
        tg->gio -= 1;
    }
    if (tg->gio<0)
    {
        tg->gio = tg->gio + 24;
    }
}

void inThoiGian(const ThoiGianPtr tg)
{
     cout<<"Thoi gian: "<<tg->gio<<":"<<tg->phut<<":"<<tg->giay<<endl;
}

bool soSanhThoiGianLonHon(const ThoiGianPtr tg1, const ThoiGianPtr tg2)
{
    ThoiGianPtr time1, time2;
    time1 = tg1;
    time2 = tg2;
    quyChuanThoiGian(time1);
    quyChuanThoiGian(time2);
    int tong1, tong2;
    tong1 = time1->gio*3600+time1->phut*60+time1->giay;
    tong2 = time2->gio*3600+time2->phut*60+time2->giay;
    if (tong1>tong2) return true;
	else return false;
}
bool soSanhThoiGianNhoHon(const ThoiGianPtr tg1, const ThoiGianPtr tg2)
{
	ThoiGianPtr time1, time2;
    time1 = tg1;
    time2 = tg2;
    quyChuanThoiGian(time1);
    quyChuanThoiGian(time2);
    int tong1, tong2;
    tong1 = time1->gio*3600+time1->phut*60+time1->giay;
    tong2 = time2->gio*3600+time2->phut*60+time2->giay;
    if (tong1<tong2) return true;
	else return false;
}
bool soSanhThoiGianBang(const ThoiGianPtr tg1, const ThoiGianPtr tg2)
{
	ThoiGianPtr time1, time2;
    time1 = tg1;
    time2 = tg2;
    quyChuanThoiGian(time1);
    quyChuanThoiGian(time2);
    int tong1, tong2;
    tong1 = time1->gio*3600+time1->phut*60+time1->giay;
    tong2 = time2->gio*3600+time2->phut*60+time2->giay;
    if (tong1==tong2) return true;
	else return false;
}
bool soSanhThoiGianKhac(const ThoiGianPtr tg1, const ThoiGianPtr tg2)
{
	ThoiGianPtr time1, time2;
    time1 = tg1;
    time2 = tg2;
    quyChuanThoiGian(time1);
    quyChuanThoiGian(time2);
    int tong1, tong2;
    tong1 = time1->gio*3600+time1->phut*60+time1->giay;
    tong2 = time2->gio*3600+time2->phut*60+time2->giay;
    if (tong1!=tong2) return true;
	else return false;
}

void chenNut(ThoiGianPtr &dau, ThoiGianPtr nutChen)
{
    //chen vao dau
    if (dau->gio >= nutChen->gio)
    {
        nutChen->tiepTheo = dau;
        dau = nutChen;
    }
    //chen vao giua danh sach lien ket
    else
    {
        ThoiGianPtr nutHienTai = dau;
        while (nutHienTai->tiepTheo != NULL && nutHienTai->tiepTheo->gio < nutChen->gio)
        {
            nutHienTai = nutHienTai->tiepTheo;
        }
        nutChen->tiepTheo = nutHienTai->tiepTheo;
        nutHienTai->tiepTheo = nutChen;
    }
}

ThoiGianPtr gopDSLK(ThoiGianPtr &dau1, ThoiGianPtr &dau2)
{
	ThoiGianPtr dau = new ThoiGian;
	ThoiGianPtr tg1 = new ThoiGian;
	tg1->tiepTheo = dau1;
	while (tg1->tiepTheo != NULL){
         tg1 = tg1->tiepTheo;
    }
    tg1->tiepTheo = dau2;
    dau2 = NULL;
    dau = dau1;
    dau1 = NULL;
	return dau;
}

void inDanhSachLienKet(const ThoiGianPtr dau)
{
     ThoiGianPtr tg1 = new ThoiGian;
     tg1 = dau;
     while (tg1 != NULL){
          cin.sync();
          cout<<"Time : "<<tg1->gio<<":"<<tg1->phut<<":"<<tg1->giay<<" -> ";
          tg1 = tg1->tiepTheo;
     }
     cout<<"NULL"<<endl;
}

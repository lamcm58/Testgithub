/* Luu y: doi voi bai tap nay,
   sinh vien khong duoc thay doi khai bao ham
   sinh vien phai cai dat ham dua tren khai bao ham duoc cung cap
*/
#include <iostream>
#include <cstdlib>

using namespace std;

struct thoigian
{
	int gio;
	int phut;
	int giay;
};
typedef struct thoigian ThoiGian;
typedef ThoiGian * ThoiGianPtr;

void docThoiGian(ThoiGian &);

void inThoiGian(const ThoiGian &);

void quyChuanThoiGian(ThoiGian &);

const ThoiGian congThoiGian(ThoiGian &, ThoiGian &);

const ThoiGian truThoiGian(ThoiGian &, ThoiGian &);

bool soSanhThoiGianLonHon(ThoiGian &, ThoiGian &);
bool soSanhThoiGianNhoHon(ThoiGian &, ThoiGian &);
bool soSanhThoiGianBang(ThoiGian &, ThoiGian &);
bool soSanhThoiGianKhac(ThoiGian &, ThoiGian &);

int main()
{
	ThoiGian tg1, tg2;

	docThoiGian(tg1);
	docThoiGian(tg2);

	inThoiGian(tg1); cout << endl;
	inThoiGian(tg2); cout << endl;

	inThoiGian(congThoiGian(tg1, tg2)); cout << endl;
	inThoiGian(truThoiGian(tg1, tg2)); cout << endl;

	if (soSanhThoiGianLonHon(tg1,tg2)) cout<<"Thoi gian 1 lon hon thoi gian 2"<<endl;
	if (soSanhThoiGianNhoHon(tg1,tg2)) cout<<"Thoi gian 1 nho hon thoi gian 2"<<endl;
	if (soSanhThoiGianBang(tg1,tg2)) cout<<"Thoi gian 1 bang thoi gian 2"<<endl;
	if (soSanhThoiGianKhac(tg1,tg2)) cout<<"Thoi gian 1 khac thoi gian 2"<<endl;

	system("PAUSE");
	return EXIT_SUCCESS;
}

void docThoiGian(ThoiGian & tg)
{
    cout<<"Nhap gio: "; cin>>tg.gio;
    cout<<"Nhap phut: "; cin>>tg.phut;
    cout<<"Nhap giay: "; cin>>tg.giay;
    quyChuanThoiGian(tg);
}

void inThoiGian(const ThoiGian & tg)
{
    cout<<"Thoi gian "<<tg.gio<<":"<<tg.phut<<":"<<tg.giay<<endl;
}

void quyChuanThoiGian(ThoiGian & tg)
{
    if (tg.giay>59)
    {
        tg.giay = tg.giay - 60;
        tg.phut += 1;
    }
    if (tg.phut>59)
    {
        tg.phut = tg.phut - 60;
        tg.gio += 1;
    }
    if (tg.gio>23)
    {
        tg.gio = tg.gio - 24;
    }

    if (tg.giay<0)
    {
        tg.giay = tg.giay + 60;
        tg.phut -= 1;
    }
    if (tg.phut<0)
    {
        tg.phut = tg.phut + 60;
        tg.gio -= 1;
    }
    if (tg.gio<0)
    {
        tg.gio = tg.gio + 24;
    }
}

const ThoiGian congThoiGian(ThoiGian & tg1, ThoiGian & tg2)
{
	ThoiGian * tg = new ThoiGian;
	int giay,phut,gio;
	giay=tg1.giay+tg2.giay;
	phut=tg1.phut+tg2.phut;
	gio=tg1.gio+tg2.gio;
	tg->giay=giay;
	tg->phut=phut;
	tg->gio=gio;
	quyChuanThoiGian(*tg);
	return (*tg);
}

const ThoiGian truThoiGian(ThoiGian & tg1, ThoiGian & tg2)
{
	ThoiGian * tg = new ThoiGian;
	int giay,phut,gio;
	giay=tg1.giay-tg2.giay;
	phut=tg1.phut-tg2.phut;
	gio=tg1.gio-tg2.gio;
	tg->giay=giay;
	tg->phut=phut;
	tg->gio=gio;
	quyChuanThoiGian(*tg);
	return (*tg);
}

bool soSanhThoiGianLonHon(ThoiGian & tg1, ThoiGian & tg2)
{
     int tong1,tong2;
     quyChuanThoiGian(tg1);
     quyChuanThoiGian(tg2);
     tong1=tg1.gio*3600+tg1.phut*60+tg1.giay;
     tong2=tg2.gio*3600+tg2.phut*60+tg2.giay;
     if (tong1>tong2)
	{
	    return true;
	}
	else return false;
}
bool soSanhThoiGianNhoHon(ThoiGian & tg1, ThoiGian & tg2)
{
    int tong1,tong2;
    quyChuanThoiGian(tg1);
    quyChuanThoiGian(tg2);
    tong1=tg1.gio*3600+tg1.phut*60+tg1.giay;
     tong2=tg2.gio*3600+tg2.phut*60+tg2.giay;
    if (tong1<tong2)
	{
	    return true;
	}
	else return false;
}
bool soSanhThoiGianBang(ThoiGian & tg1, ThoiGian & tg2)
{
    int tong1,tong2;
    quyChuanThoiGian(tg1);
    quyChuanThoiGian(tg2);
    tong1=tg1.gio*3600+tg1.phut*60+tg1.giay;
     tong2=tg2.gio*3600+tg2.phut*60+tg2.giay;
    if (tong1==tong2)
	{
	    return true;
	}
	else return false;
}
bool soSanhThoiGianKhac(ThoiGian & tg1, ThoiGian & tg2)
{
    int tong1,tong2;
    quyChuanThoiGian(tg1);
    quyChuanThoiGian(tg2);
    tong1=tg1.gio*3600+tg1.phut*60+tg1.giay;
    tong2=tg2.gio*3600+tg2.phut*60+tg2.giay;
    if (tong1!=tong2)
	{
	    return true;
	}
	else return false;
}

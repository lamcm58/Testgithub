#include <cstdlib>
#include <iostream>

using namespace std;

class SoHuuTi
{
	public:
		SoHuuTi(int, int);
		~SoHuuTi();

		void setSoHuuTi(int, int);
		
		int getTuso()const;
		int getMauso()const;

		friend istream& operator>> (istream&, const SoHuuTi&);
		friend ostream& operator<< (ostream&, const SoHuuTi&);

        // truoc ++t
        const SoHuuTi operator++();
        // sau t++
        const SoHuuTi operator++(int);

		friend const SoHuuTi operator+ (const SoHuuTi&, const SoHuuTi&);
		friend const SoHuuTi operator- (const SoHuuTi&, const SoHuuTi&);
		friend const SoHuuTi operator- (const SoHuuTi&);

		friend bool operator< (const SoHuuTi&, const SoHuuTi&);
		friend bool operator> (const SoHuuTi&, const SoHuuTi&);
		friend bool operator!= (const SoHuuTi&, const SoHuuTi&);
	private:
		void quyChuanSoHuuTi();
		int Tuso;
		int Mauso;
};

const SoHuuTi operator* (const SoHuuTi&, const SoHuuTi&);
const SoHuuTi operator/ (const SoHuuTi&, const SoHuuTi&);
const SoHuuTi operator% (const SoHuuTi&, const SoHuuTi&);

bool operator<= (const SoHuuTi&, const SoHuuTi&);
bool operator>= (const SoHuuTi&, const SoHuuTi&);
bool operator== (const SoHuuTi&, const SoHuuTi&);

SoHuuTi::SoHuuTi(int Tuso,int Mauso)
{
	setSoHuuTi(Tuso,Mauso);
}

void SoHuuTi::setSoHuuTi(int Tuso,int Mauso)
{
	this->Tuso=Tuso;
	this->Mauso=Mauso;
	quyChuanSoHuuTi();
}

int SoHuuTi::getTuso()const
{
	return Tuso;
}

int SoHuuTi::getMauso()const
{
	return Mauso;
}

SoHuuTi::~SoHuuTi()
{
}

ostream& operator<<(ostream& os, const SoHuuTi& so)
{
	os<<"("<<so.Tuso<<"/"<<so.Mauso<<")"<<endl;
	return os;
}

istream& operator>>(istream& is, const SoHuuTi& so)
{
	int tu=so.Tuso, mau=so.Mauso;
	cout<<"Nhap tu va mau: ";
	is>>tu>>mau;
	return is;
}

const SoHuuTi SoHuuTi::operator++()
{
	Tuso++;
	Mauso++;
	quyChuanSoHuuTi();
	return SoHuuTi(Tuso, Mauso);
}

const SoHuuTi SoHuuTi::operator++(int a)
{
	int tu=Tuso;
	int mau=Mauso;
	Tuso++;
	Mauso++;
	quyChuanSoHuuTi();
	return SoHuuTi(tu, mau);
}

const SoHuuTi operator+ (const SoHuuTi& so1, const SoHuuTi& so2)
{
	int tu1=so1.Tuso, tu2=so2.Tuso, mau1=so1.Mauso, mau2=so2.Mauso;
	int Tu,Mau;
	Tu=tu1*mau2+tu2*mau1;
	Mau=mau1*mau2;
	
	return SoHuuTi(Tu, Mau);
}

const SoHuuTi operator- (const SoHuuTi& so1, const SoHuuTi& so2)
{
	int tu1=so1.Tuso, tu2=so2.Tuso, mau1=so1.Mauso, mau2=so2.Mauso;
	int Tu, Mau;
	Tu=tu1*mau2-tu2*mau1;
	Mau=mau1*mau2;
	
	return SoHuuTi(Tu, Mau);
}

const SoHuuTi operator- (const SoHuuTi& so)
{	
	return SoHuuTi(-so.Tuso, so.Mauso);
}

const SoHuuTi operator* (const SoHuuTi& so1, const SoHuuTi& so2)
{
	int tu = so1.getTuso() * so2.getTuso();
	int mau = so1.getMauso() * so2.getMauso();
	return SoHuuTi(tu, mau);
}

const SoHuuTi operator/ (const SoHuuTi& so1, SoHuuTi& so2)
{
	int tu = so1.getTuso() * so2.getMauso();
	int mau = so1.getMauso() * so2.getTuso();
	return SoHuuTi(tu, mau);
}

bool operator< (const SoHuuTi& so1, const SoHuuTi& so2)
{
	return (so1.Tuso/so1.Mauso < so2.Tuso/so2.Mauso);
}

bool operator> (const SoHuuTi& so1, const SoHuuTi& so2)
{
	return (so1.Tuso/so1.Mauso > so2.Tuso/so2.Mauso);
}

bool operator!= (const SoHuuTi& so1, const SoHuuTi& so2)
{
	return (so1.Tuso/so1.Mauso != so2.Tuso/so2.Mauso);
}

bool operator== (const SoHuuTi& so1, const SoHuuTi& so2)
{
	return !(so1!=so2);
}

bool operator<= (const SoHuuTi& so1, const SoHuuTi& so2)
{
	return ((so1<so2)||(so1==so2));
}

bool operator>= (const SoHuuTi& so1, const SoHuuTi& so2)
{
	return ((so1>so2)||(so1==so2));
}

void SoHuuTi::quyChuanSoHuuTi()
{
	int a=Tuso, b=Mauso, c;
    while (b!=0){
        c=a%b;
        a=b;
        b=c;
    }
    Tuso = Tuso/a;
    Mauso = Mauso/a;
}

int main()
{
	int n,i,j;
	int h,k;
	cout<<"Nhap so phan tu cua day: ";
	cin>>n;
	for (i=0; i<n; i++)
	{
		cout<<"\nSo thu "<<i+1<<": "<<endl;
		cout<<"Nhap tu : "; cin>>h;
		cout<<"Nhap mau : "; cin>>k;
		SoHuuTi a(h,k);
		cout<<a;
	}
	
	system("PAUSE");
	return EXIT_SUCCESS;
}


#include <cstdlib>
#include <iostream>

using namespace std;

class Tien
{
	public:
		Tien(int, int);
		~Tien();

		void setTien(int, int);
		int getDong()const;
		int getXu()const;

		friend istream& operator>> (istream&, const Tien&);
		friend ostream& operator<< (ostream&, const Tien&);

        // truoc ++t
        const Tien operator++();
        // sau t++
        const Tien operator++(int);

		friend const Tien operator+ (const Tien&, const Tien&);
		friend const Tien operator- (const Tien&, const Tien&);
		friend const Tien operator- (const Tien&);

		friend bool operator< (const Tien&, const Tien&);
		friend bool operator> (const Tien&, const Tien&);
		friend bool operator!= (const Tien&, const Tien&);
	private:
		void quyChuanTien();
		int Dong;
		int Xu;
};

const Tien operator* (const Tien&, int);
const Tien operator/ (const Tien&, int);

bool operator<= (const Tien&, const Tien&);
bool operator>= (const Tien&, const Tien&);
bool operator== (const Tien&, const Tien&);

Tien::Tien(int Dong, int Xu)
{
	setTien(Dong, Xu);
}

void Tien::setTien(int Dong, int Xu)
{
	this->Dong=Dong;
	this->Xu=Xu;
	quyChuanTien();
}

int Tien::getDong()const
{
	return Dong;
}

int Tien::getXu()const
{
	return Xu;
}

Tien::~Tien()
{
}

istream& operator>> (istream& is, const Tien& tien)
{
	int a=tien.Dong, b=tien.Xu;
	is>>a>>b;
	return is;
}

ostream& operator<< (ostream& os, const Tien& tien)
{
	if(tien.Xu<9)
	{
		os<<"$"<<tien.Dong<<"."<<0<<tien.Xu<<endl;
	}
	else{
		os<<"$"<<tien.Dong<<"."<<tien.Xu<<endl;
	}
	return os;
}

const Tien Tien::operator++()
{
	Dong++;
	quyChuanTien();
	return Tien(Dong, Xu);
}

const Tien Tien::operator++(int a)
{
	int dong=Dong;
	Dong++;
	quyChuanTien();
	return Tien(dong, Xu);
}

const Tien operator+ (const Tien& tien1, const Tien& tien2)
{
	int dong1=tien1.Dong, dong2=tien2.Dong, xu1=tien1.Xu, xu2=tien2.Xu;
	int dong, xu;
	dong=dong1+dong2;
	xu=xu1+xu2;
	return Tien(dong,xu);
}

const Tien operator- (const Tien& tien1, const Tien& tien2)
{
	int dong1=tien1.Dong, dong2=tien2.Dong, xu1=tien1.Xu, xu2=tien2.Xu;
	int dong, xu;
	dong=dong1-dong2;
	xu=xu1-xu2;
	return Tien(dong,xu);
}

const Tien operator- (const Tien& tien)
{
	return Tien(-tien.Dong, tien.Xu);
}

const Tien operator* (const Tien& tien, int a)
{
	return Tien(a*tien.getDong(), a*tien.getXu());
}

const Tien operator/ (const Tien& tien, int a)
{
	return Tien(tien.getDong()/a,tien.getXu()/a);
}

bool operator< (const Tien& tien1, const Tien& tien2)
{
	return (tien1.Dong<tien2.Dong || (tien1.Dong==tien2.Dong && tien1.Xu<tien2.Xu));
}

bool operator> (const Tien& tien1, const Tien& tien2)
{
	return (tien1.Dong>tien2.Dong || (tien1.Dong==tien2.Dong && tien1.Xu>tien2.Xu));
}

bool operator!= (const Tien& tien1, const Tien& tien2)
{
	return (tien1.Xu!=tien2.Xu);
}

bool operator<= (const Tien& tien1, const Tien& tien2)
{
	return (tien1<tien2||tien1==tien2);
}

bool operator>= (const Tien& tien1, const Tien& tien2)
{
	return (tien1>tien2||tien1==tien2);
}

bool operator== (const Tien& tien1, const Tien& tien2)
{
	return (tien1.getDong()==tien2.getDong() && tien1.getXu()==tien2.getXu());
}

void Tien::quyChuanTien()
{
	int a=Dong, b=Xu;
	while (b>99)
	{
		a+=b/100;
		b%=100;
	}
	if (a<0 && b<0)
	{
		a=a;
		b=-b;
	}
	else if (a>=0 && b<0)
	{
		b+=100;
		a-=1;
	}
	Dong = a;
	Xu = b;
}

int main()
{
	Tien a(4,105);
	cout<<"a = ";
	cout<<a<<endl;
	Tien b(6,50);
	cout<<"b = ";
	cout<<b<<endl;
	
	Tien c=a+b;
	cout<<"c = a + b = ";
	cout<<c;
	Tien d=a-b;
	cout<<"d = a - d = ";
	cout<<d<<endl;
	
	Tien e=a*8;
	cout<<"e = ";
	cout<<e;
	Tien f=c/3;
	cout<<"f = ";
	cout<<f<<endl;
	
	if (a>b) cout<<"a > b";
	else cout<<"a < b"<<endl;
	if (c>a) cout<<"c > a";
	else cout<<"c < a"<<endl;
	cout<<endl;
	
	system("PAUSE");
	return EXIT_SUCCESS;
}


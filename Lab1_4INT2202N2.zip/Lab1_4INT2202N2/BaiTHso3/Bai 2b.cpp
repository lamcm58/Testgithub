#include<iostream>
using namespace std;
int main()
{
    int N,i;
    int a,b,c;
    int Tong;
    cout<<"Nhap vao so phan tu: ";
    cin>>N;
    a=1; b=1; c=0;
    if (N<0)
    {
        cout<<"Nhap sai"<<endl;
    }
    Tong = 0;
    //Hien day Fibonacci
    cout<<"\nDay Fibonacci: ";
    for (i=0;i<=N;i++)
    {
        cout<<"\t"<<c;
        a=b;
        b=c;
        c=b+a;
        Tong+=b;
    }
    //Tinh tong N so dau day Fibonacci                         
    cout<<"\n\nTong "<<N+1<<" so dau cua day Fibonacci la: "<<Tong<<endl;                    
    system("pause");
}         

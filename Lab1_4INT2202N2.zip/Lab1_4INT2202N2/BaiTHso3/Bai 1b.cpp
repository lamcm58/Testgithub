#include<iostream>
using namespace std;
int main()
{
    int N;
    int n;
    int Fib1,Fib2,Fibn;
    cout<<"Nhap vao mot so: ";
    cin>>N;
    Fib1=1;
    Fib2=1;
    Fibn=0;
    for(n=0;n<=N;n++)
    {
        Fib1=Fib2;
        Fib2=Fibn;             
        Fibn=Fib2+Fib1;
    }
    cout<<"\nSo thu "<<N+1<<" cua day Fibonacci la: "<<Fib2<<endl;
    system("pause");
}                          

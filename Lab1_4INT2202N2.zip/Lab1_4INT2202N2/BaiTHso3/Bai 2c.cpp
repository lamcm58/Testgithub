#include<iostream>
using namespace std;
int fib(int);
int Tong(int);
int main()
{
    int n,i;
    int TongFib;
    cout<<"Nhap vao mot so: ";
    cin>>n;
    //Hien thi day Fibonacci
    cout<<"\nDay Fibonaci: ";
    for (i=0;i<=n;i++)
    {
        cout<<"\t"<<fib(i);
    }
    //Tinh tong N so dau cua day Fibonacci
    TongFib=Tong(n);
    cout<<"\n\nTong "<<n+1<<" so dau day Fibonacci la: "<<TongFib<<endl;
    system("pause");
}     
int fib(int n)
{
    if (n==0) {return 0;}
    if (n==1||n==2) {return 1;}
    else {
         return (fib(n-1)+fib(n-2));
         }         
}
int Tong(int n)
{
    int Tong=0;
    int i;
    for (i=1;i<=n;i++)
    {
        Tong+=fib(i);
    }
    return Tong;
}
    

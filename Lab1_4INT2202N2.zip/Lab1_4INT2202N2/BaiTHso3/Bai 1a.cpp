#include<iostream>
using namespace std;
int main()
{
    int a; 
    int TongCS;
    cout<<"Nhap vao mot so: ";
    cin>>a;
    TongCS=0;
    while (a){
        TongCS+=a%10;
        a/=10;
        }
    cout<<"\nTong cua cac chu so cua so do la: "<<TongCS<<endl;	
    system("pause");
}                

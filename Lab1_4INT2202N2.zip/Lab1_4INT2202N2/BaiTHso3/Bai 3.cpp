#include<iostream>
using namespace std;
int doiHeSo(int,int,int);
int main()
{
    int N;
    int a,b;
    int heso;
    cout<<"Nhap mot so: ";
    cin>>N;
    cout<<"Nhap co so ban dau: ";
    cin>>a;
    cout<<"Nhap co so muon doi thanh: ";
    cin>>b;
    heso = doiHeSo(N,a,b);
    cout<<N<<" trong he "<<a<<" la "<<heso<<" trong he "<<b<<endl; 
    system("pause");
}
int doiHeSo(int N, int a, int b)
{
    // doi tu he a sang he 10
    int soHe10 = 0;
    int soMuHea = 1;
    while (N>0)
    {
        soHe10 += N%10 * soMuHea;
        soMuHea *= a;
        N /= 10;
    }
    // doi tu he 10 sang he b
    int soHeb = 0;
    int soMuHe10 = 1;
    while (soHe10>0)
    {
        soHeb += (soHe10 % b) * soMuHe10;
        soMuHe10 *= 10;
        soHe10 /= b;
    }
    return soHeb;
}

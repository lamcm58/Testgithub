#include<iostream>
using namespace std;
int TongCS(int);
int main()
{
    int N;
    int Tong;
    cout<<"Nhap vao mot so: ";
    cin>>N;
    Tong = TongCS(N);
    cout<<"\nTong cac chu so cua so do la: "<<Tong<<endl;
    system("pause");
}
int TongCS(int N)
{
    int TongCS;
    while (N){
          TongCS+=N%10;
          N/=10;
          }
    return TongCS;
}                      

#include<iostream>
using namespace std;
int Fib(int);
int main()
{
    int N;
    int fn;
    cout<<"Nhap vao mot so: ";
    cin>>N;
    fn=Fib(N);
    cout<<"\nSo thu "<<N+1<<" cua day Fibonacci la: "<<fn<<endl;
    system("pause");
}
int Fib(int N)
{
    if (N==0) {return 0;}
    if (N==1||N==2) {return 1;}
    else {
         return (Fib(N-1)+Fib(N-2));
         }         
}

#include<iostream>
using namespace std;

const double Bao_hiem=0.09;
const double Muc_thue_1=0.0;
const double Muc_thue_2=0.10;
const double Muc_thue_3=0.15;
const double Muc_thue_4=0.20;
    
int main()
{
    int Luong;
    double Thue=0.00;
    double Tien_bao_hiem;
    cout<<"Nhap vao thu nhap cua ban: ";
    cin>>Luong;
    Tien_bao_hiem=Luong*Bao_hiem;
    int Thu_nhap_chiu_thue;
    Thu_nhap_chiu_thue=Luong-Tien_bao_hiem;
    if (Thu_nhap_chiu_thue>2000000)
    {
        Thue+=1000000*Muc_thue_1+500000*Muc_thue_2+500000*Muc_thue_3+(Thu_nhap_chiu_thue-2000000)*Muc_thue_4;
    }
    else if (Thu_nhap_chiu_thue>1500000)
    {
        Thue+=1000000*Muc_thue_1+500000*Muc_thue_2+(Thu_nhap_chiu_thue-1500000)*Muc_thue_3;
    }
    else if (Thu_nhap_chiu_thue>1000000)
    {
         Thue+=1000000*Muc_thue_1+(Thu_nhap_chiu_thue-1000000)*Muc_thue_2;
    }
    else if (Thu_nhap_chiu_thue<=1000000)
    {
         Thue+=Thu_nhap_chiu_thue*Muc_thue_1;
    }
    int Thu_nhap_sau_thue;
    Thu_nhap_sau_thue=Luong-Tien_bao_hiem-Thue;
    cout<<"\nThu nhap sau thue cua ban la: "<<Thu_nhap_sau_thue<<" dong"<<endl;                                        
    system("pause");
}

#include<iostream>
using namespace std;

const double Lai_suat=0.02;
const int Tro_cap=1500000;
const int Sinh_hoat=2000000;

const int Muc_luong_1=12000;
const int Muc_luong_2=16000;
const int Muc_luong_3=20000;
const int Muc_luong_4=25000;

const double Bao_hiem=0.09;
const double Muc_thue_1=0.00;
const double Muc_thue_2=0.10;
const double Muc_thue_3=0.15;
const double Muc_thue_4=0.20;

const int MucThuNhap1=1000000;
const int MucThuNhap2=1500000;
const int MucThuNhap3=2000000;

int main()
{
    int Tienvay,Tientra, Sothang=0;
    cout<<"Nhap so tien ma nguoi do vay: ";
    cin>>Tienvay;
    Tientra = Tienvay;
    while (Tientra>0)
    {
          Sothang++;
          Tientra += Tientra*Lai_suat;
          
          int giolam,luong=0;
          cout<<"\nNhap so gio lam cua nguoi do o thang thu "<<Sothang<<" : "; cin>>giolam;
          if(giolam>200){luong+=100*Muc_luong_1+50*Muc_luong_2+50*Muc_luong_3+(giolam-200)*Muc_luong_4;}
          else if(giolam>150){luong+=100*Muc_luong_1+50*Muc_luong_2+(giolam-150)*Muc_luong_3;} 
          else if(giolam>100){luong+=100*Muc_luong_1+(giolam-100)*Muc_luong_2;}
          else if(giolam<=100){luong+=giolam*Muc_luong_1;}
          
          int ThuNhap,ThuNhapChiuThue,ThuNhapSauThue;
          ThuNhap=luong;
          ThuNhapChiuThue=ThuNhap*(1-Bao_hiem);
          if (ThuNhapChiuThue<=MucThuNhap1)
          {
              ThuNhapSauThue = ThuNhapChiuThue;
          }
          else if(ThuNhapChiuThue<=MucThuNhap2)
          {
               ThuNhapSauThue=ThuNhapChiuThue-((MucThuNhap2-MucThuNhap1)*Muc_thue_2);
          }
          else if (ThuNhapChiuThue<=MucThuNhap3)
          {
               ThuNhapSauThue=ThuNhapChiuThue-((MucThuNhap2-MucThuNhap1)*Muc_thue_2
                                               +(ThuNhapChiuThue-MucThuNhap2)*Muc_thue_3);
          }
          else
          {
               ThuNhapSauThue=ThuNhapChiuThue-((MucThuNhap2-MucThuNhap1)*Muc_thue_2 
                                               +(MucThuNhap3-MucThuNhap2)*Muc_thue_3
                                               +(ThuNhapChiuThue-MucThuNhap3)*Muc_thue_4);
          }           
          cout<<"Thu nhap sau thue cua nguoi do thang thu "<<Sothang<<" :"<<ThuNhapSauThue<<endl; 
          cout<<"So tien lai ngan hang cuoi thang thu "<<Sothang<<" ="<<Tientra<<endl;                    
          int TienTraNganHang;
          TienTraNganHang=ThuNhapSauThue + Tro_cap - Sinh_hoat;
          if (TienTraNganHang>0)
          {
              if (Tientra<=TienTraNganHang)
              {
                  cout<<"\nKhoan thanh toan cuoi cung= "<<Tientra<<endl;
                  Tientra=0;
              }
              else 
              {
                  Tientra -= TienTraNganHang;
              }
              cout<<"So tien du no dau thang thu "<<Sothang+1<<" ="<<Tientra<<endl;
          }                                                                
    }
    cout<<"\nSau "<<Sothang+1<<" thang nguoi do se tra duoc het no"<<endl;
    system("pause");
}

#include<iostream>
using namespace std;
const int Luong_toi_thieu=12000;
const int Luong_muc_1=16000;
const int Luong_muc_2=20000;
const int Luong_muc_3=25000;
int main()
{
    int GioLam;
    int Luong=0;
    cout<<"Nhap vao so gio lam cua ban: ";
    cin>>GioLam;
    
    if (GioLam>200)
    {
         Luong += 100*Luong_toi_thieu + 50*Luong_muc_1 + 50*Luong_muc_2 + (GioLam-200)*Luong_muc_3;
    }
    else if (GioLam>150)
    {
         Luong += 100*Luong_toi_thieu + 50*Luong_muc_1 + (GioLam-150)*Luong_muc_2;
    }
    else if (GioLam>100)
    {
         Luong += 100*Luong_toi_thieu + (GioLam-100)*Luong_muc_1;
    }
    else if (GioLam<=100)
    {
        Luong += GioLam*Luong_toi_thieu;
    }
    cout<<"\nLuong cua ban la: "<<Luong<<" dong"<<endl;                     
    system("pause");
}
                   

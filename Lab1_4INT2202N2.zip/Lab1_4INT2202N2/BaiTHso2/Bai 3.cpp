#include<iostream>
using namespace std;
int main()
{
    int Tien_vay;
    int thang;
    int Tien_tra;
    int i;
    const double Lai_suat=0.02;
    cout<<"Nhap vao so tien ban muon vay: ";
    cin>>Tien_vay;
    cout<<"\nNhap vao thang ban muon tra: ";
    cin>>thang;
    Tien_tra=Tien_vay;
    for (i=1;i<=thang;i++)
    {
        Tien_tra+=(Tien_tra*Lai_suat);
    }
    cout<<"\nSo tien ban phai tra la: "<<Tien_tra<<" dong"<<endl;
    system("pause");
}

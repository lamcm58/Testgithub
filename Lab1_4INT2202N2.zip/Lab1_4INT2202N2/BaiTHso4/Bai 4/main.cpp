#include<iostream>
#include<cstdlib>
#include<time.h>
#include"Xucxac.h"
#include"Nguoichoi.h"
using namespace std;
int main()
{
    int Tong1=0, Tong2=0;//Tong diem 2 nguoi choi
    srand(time(0));
    do{
        if(Tong1<=Tong2) {Nguoi1(Tong1);}
        else{
             Nguoi2(Tong2);}
        
        if (Tong1==100)
        {
            cout<<"\nNguoi choi 1 thang!!"<<endl;
            break;
        }               
        if (Tong2==100)
        {
            cout<<"\nNguoi choi 2 thang!!"<<endl;
            break;
        }
    }
    while (Tong1<100||Tong2<100);
    system("pause");
}

#include<iostream>
int Nguoi1(int&);
int Nguoi2(int&);

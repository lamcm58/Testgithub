#include"Xucxac.h"
#include<cstdlib>
using namespace std;

int Nguoi1(int& Tong1)
{
    int a1,a2;
    a1=rand()%6 + 1;
    a2=rand()%6 + 1;
    if(a1+a2+Tong1>100||a1+a2+Tong1==99)
    {
        cout<<"\nXuc xac nguoi 1: "<<a1<<" va "<<a2<<" ";
        cout<<"Nguoi 1 khong nhan diem"<<endl;
        return Nguoi1(Tong1);
    }
    else{
         cout<<"\nXuc xac nguoi 1: "<<a1<<" va "<<a2<<" ";
         Tong1+=a1+a2;
         cout<<"Diem nguoi choi 1= "<<Tong1<<endl;
         }
}
int Nguoi2(int& Tong2)
{
    int b1,b2;
    b1=rand()%6 + 1;
    b2=rand()%6 + 1;
    if(b1+b2+Tong2>100||b1+b2+Tong2==99)
    {
        cout<<"\nXuc xac nguoi 2: "<<b1<<" va "<<b2<<" ";
        cout<<"Nguoi 2 khong nhan diem"<<endl;
        return Nguoi2(Tong2);
    }
    else{
         cout<<"\nXuc xac nguoi 2: "<<b1<<" va "<<b2<<" ";
         Tong2+=b1+b2;
         cout<<"Diem nguoi choi 2= "<<Tong2<<endl;
         }
}                  

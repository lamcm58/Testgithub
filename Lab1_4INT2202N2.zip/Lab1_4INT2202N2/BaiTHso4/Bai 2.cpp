#include<iostream>
#include<cstdlib>
#include<time.h>

using namespace std;
int main()
{
    int n, i;
    int diem;
    cout<<"Nhap vao so lan choi: ";
    cin>>n;
    srand(time(0));
    for (i=1;i<=n;i++)
    {
        diem=(rand()%6 +1);
        cout<<"\nSo diem cua ban o lan choi thu "<<i<<" la: "<<diem<<endl;
    }
    system("pause");
}

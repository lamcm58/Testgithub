#include<iostream>
using namespace std;
int UCLN(int,int);
int main()
{
    int a,b;
    int usln;
    cout<<"Nhap so thu nhat: ";
    cin>>a;
    cout<<"Nhap so thu hai: ";
    cin>>b;
    usln=UCLN(a,b);
    cout<<"\nUoc chung lon nhat cua "<<a<<" va "<<b<<" la: "<<usln<<endl;
    system("pause");
}
int UCLN(int a,int b)
{
    int tam;
    while (b!=0){
          tam = a%b;
          a = b;
          b = tam;
          }
    return a;
}          

#include <cstdlib>
#include <iostream>
#include <time.h>
#include <cmath>


using namespace std;

class SoHuuTi
{
	public:
		SoHuuTi();
		SoHuuTi(int, int);
		~SoHuuTi();

		void setSoHuuTi(int, int);
		void inSoHuuTi();

		void congSoHuuTi(const SoHuuTi&);
		void truSoHuuTi(const SoHuuTi&);
		void nhanSoHuuTi(const SoHuuTi&);
		void chiaSoHuuTi(const SoHuuTi&);

		bool soSanhSoHuuTi(const SoHuuTi&, const SoHuuTi&);
		void doichoSoHuuTi(SoHuuTi&, SoHuuTi&);
	private:
        void quyChuanSoHuuTi();
        int TuSo;
        int MauSo;

};

void SoHuuTi::quyChuanSoHuuTi()
{
    int a=TuSo, b=MauSo, c;
    while (b!=0){
        c=a%b;
        a=b;
        b=c;
    }
    TuSo = TuSo/a;
    MauSo = MauSo/a;
}

SoHuuTi::SoHuuTi()
{
    TuSo = 0;
    MauSo = 1;
}

SoHuuTi::SoHuuTi(int TuSo, int MauSo)
{
    this->TuSo = TuSo;
    this->MauSo = MauSo;
}

SoHuuTi::~SoHuuTi()
{
}

void SoHuuTi::setSoHuuTi(int TuSo, int MauSo)
{
    this->TuSo = TuSo;
    this->MauSo = MauSo;
}

void SoHuuTi::inSoHuuTi()
{
    quyChuanSoHuuTi();
    cout<<"("<<TuSo<<"/"<<MauSo<<")"<<endl;
}

void SoHuuTi::congSoHuuTi(const SoHuuTi& so)
{
    int a,b;
    a=TuSo;
    b=MauSo;
    MauSo = b*so.MauSo;
    TuSo = a*so.MauSo + b*so.TuSo;
}

void SoHuuTi::truSoHuuTi(const SoHuuTi& so)
{
    int a,b;
    a=TuSo;
    b=MauSo;
    MauSo = b*so.MauSo;
    TuSo = a*so.MauSo - b*so.TuSo;
}

void SoHuuTi::nhanSoHuuTi(const SoHuuTi& so)
{
    int a=TuSo, b=MauSo;
    TuSo = a * so.TuSo;
    MauSo = b * so.MauSo;
}

void SoHuuTi::chiaSoHuuTi(const SoHuuTi& so)
{
    int a=TuSo, b=MauSo;
    TuSo = a * so.MauSo;
    MauSo = b * so.TuSo;
}

bool SoHuuTi::soSanhSoHuuTi(const SoHuuTi& so1, const SoHuuTi& so2)
{
    double tu1=so1.TuSo, tu2=so2.TuSo, mau1=so1.MauSo, mau2=so2.MauSo;
    double giaTri1 = tu1/mau1, giaTri2 = tu2/mau2;
    if (giaTri1<=giaTri2)return true;
    else return false;
}

void SoHuuTi::doichoSoHuuTi(SoHuuTi& so1, SoHuuTi& so2)
{
    int tu, mau;
    tu = so1.TuSo;
    so1.TuSo = so2.TuSo;
    so2.TuSo = tu;
    mau = so1.MauSo;
    so1.MauSo = so2.MauSo;
    so2.MauSo = mau;
    so1.setSoHuuTi(so1.TuSo, so1.MauSo);
    so2.setSoHuuTi(so2.TuSo, so2.MauSo);
}

int main()
{
    SoHuuTi a[100];
    int n,i,j;
    int tu,mau;
    cout<<"Nhap so phan tu cua mang: ";
    cin>>n;
    srand(time(NULL));
    for (i=0; i<n; i++)
    {
        tu=rand()%100;
        mau=rand()%100+1;
        a[i].setSoHuuTi(tu,mau);
    }
    for (i=0; i<n; i++)
    {
        cout<<"So thu "<<i+1<<": ";
        a[i].inSoHuuTi();
    }

    for (i=0; i<n-1; i++){
        for (j=i+1; j<n; j++){
            if (a[i].soSanhSoHuuTi(a[i], a[j])==true){
                a[i].doichoSoHuuTi(a[i], a[j]);
            }
        }
    }

    cout<<"Mang sau khi sap xep: "<<endl;
    for (i=0; i<n; i++)
    {
        a[i].inSoHuuTi();
    }

	system("PAUSE");
	return EXIT_SUCCESS;
}


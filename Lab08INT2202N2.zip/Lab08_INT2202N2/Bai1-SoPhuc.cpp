#include <cstdlib>
#include <iostream>
#include <time.h>

using namespace std;

class SoPhuc
{
	public:
		SoPhuc();
		SoPhuc(double, double);
		~SoPhuc();

		void setSoPhuc(double, double);
		void inSoPhuc();

		void congSoPhuc(const SoPhuc&);
		void truSoPhuc(const SoPhuc&);
		void nhanSoPhuc(const SoPhuc&);
	private:
		double phanThuc;
		double phanAo;
};

SoPhuc::SoPhuc()
{
	phanThuc = 0;
	phanAo = 0;
}

SoPhuc::SoPhuc(double phanThuc, double phanAo)
{
	this->phanThuc = phanThuc;
	this->phanAo = phanAo;
}

SoPhuc::~SoPhuc()
{
}

void SoPhuc::setSoPhuc(double phanThuc, double phanAo)
{
	this->phanThuc = phanThuc;
	this->phanAo = phanAo;
}

void SoPhuc::inSoPhuc()
{
	cout << "(" << phanThuc << " + " << phanAo << "i)" << endl;
}

void SoPhuc::congSoPhuc(const SoPhuc& sp)
{
	phanThuc = phanThuc + sp.phanThuc;
	phanAo = phanAo + sp.phanAo;
}

void SoPhuc::truSoPhuc(const SoPhuc& sp)
{
    phanThuc = phanThuc - sp.phanThuc;
    phanAo = phanAo - sp.phanAo;
}

void SoPhuc::nhanSoPhuc(const SoPhuc& sp)
{
    double thuc=phanThuc, ao=phanAo;
    phanThuc = thuc*sp.phanThuc - ao*sp.phanAo;
    phanAo = thuc*sp.phanAo + ao*sp.phanThuc;
}

int main()
{
    srand(time(NULL));
	SoPhuc a;
	cout<<"a = ";
	a.setSoPhuc(rand()%10,rand()%10);
	a.inSoPhuc();

    cout<<"b = ";
	SoPhuc b(rand()%10,rand()%10);
	b.inSoPhuc();

    cout<<"Cong hai so phuc: ";
    cout<<"a + b = ";
	b.congSoPhuc(a);
	b.inSoPhuc();

	SoPhuc c;
	cout<<"\nc = ";
	c.setSoPhuc(rand()%10,rand()%10);
	c.inSoPhuc();

    cout<<"d = ";
	SoPhuc d(rand()%10,rand()%10);
	d.inSoPhuc();

    cout<<"Tru hai so phuc: ";
    cout<<"c - d = ";
	c.truSoPhuc(d);
	c.inSoPhuc();

    cout<<"\nNhan hai so phuc: ";
    cout<<"a * d = ";
	d.nhanSoPhuc(a);
	d.inSoPhuc();

	system("PAUSE");
	return EXIT_SUCCESS;
}

#include<iostream>
#include<cstdlib>
#include<cmath>
#include<ctime>

using namespace std;

class Diem2D{
    public:
        Diem2D();
        Diem2D(int, int);
        ~Diem2D();

        void setX(int);
        void setY(int);
        void inToaDo();

        int getX();
        int getY();

        void khoangCachDiem(const Diem2D&, const Diem2D&);

    private:
        int x;
        int y;
};

Diem2D::Diem2D()
{
    x=0;
    y=0;
}

Diem2D::Diem2D(int x, int y)
{
    this->x=x;
    this->y=y;
}

Diem2D::~Diem2D()
{
}

void Diem2D::setX(int x)
{
    this->x=x;
}

void Diem2D::setY(int y)
{
    this->y=y;
}

void Diem2D::inToaDo()
{
    cout<<"("<<x<<","<<y<<")"<<endl;
}

int Diem2D::getX()
{
    return x;
}

int Diem2D::getY()
{
    return y;
}

void Diem2D::khoangCachDiem(const Diem2D& toado1, const Diem2D& toado2)
{
    double x1,y1,x2,y2;
    x1=toado1.x;
    y1=toado1.y;
    x2=toado2.x;
    y2=toado2.y;
    double gt;
    gt = sqrt((x2-x1)*(x2-x1)+(y2-y1)*(y2-y1));
    cout<<gt;
}

int main()
{
    srand(time(NULL));
    Diem2D a;
    cout<<"Toa do diem thu nhat: ";
    a.setX(rand()%20-rand()%20);
    a.setY(rand()%20-rand()%20);
    a.inToaDo();

    cout<<"\nToa do diem thu hai: ";
    Diem2D b(rand()%20-rand()%20,rand()%20-rand()%20);
    b.inToaDo();

    cout<<"\nKhoang cach giua hai diem: ";
    b.khoangCachDiem(a,b);
    cout<<endl;

    system("PAUSE");
    return EXIT_SUCCESS;
}

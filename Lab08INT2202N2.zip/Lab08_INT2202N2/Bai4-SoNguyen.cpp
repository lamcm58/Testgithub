#include <cstdlib>
#include <iostream>
#include <time.h>

using namespace std;

class SoNguyen
{
	public:
		SoNguyen();
		SoNguyen(int);
		~SoNguyen();

        void setSoNguyen(int);
		void inSoNguyen();

		bool kiemTraSoNguyen(const SoNguyen&);

		static void inSoLuongSoNguyenDuongDaTao();
	private:
		static int soLuongSoNguyenDuongDaTao;
		int soNguyen;
};

int SoNguyen::soLuongSoNguyenDuongDaTao = 0;

SoNguyen::SoNguyen()
{
    soNguyen=0;
}

SoNguyen::SoNguyen(int soNguyen)
{
    this->soNguyen=soNguyen;
}

SoNguyen::~SoNguyen()
{
}

void SoNguyen::setSoNguyen(int soNguyen)
{
    this->soNguyen=soNguyen;
}

void SoNguyen::inSoNguyen()
{
    cout<<"("<<soNguyen<<")"<<endl;
}

bool SoNguyen::kiemTraSoNguyen(const SoNguyen& so)
{
    int gt=so.soNguyen;
    if (gt>0)return true;
    else return false;
}

void SoNguyen::inSoLuongSoNguyenDuongDaTao()
{
    soLuongSoNguyenDuongDaTao++;
    int tong;
    tong = soLuongSoNguyenDuongDaTao;
    //cout<<"\nSo luong so nguyen duong da tao la: "<<tong<<endl;
    cout<<tong-1;
}

int main()
{
    srand(time(NULL));
    SoNguyen a[100];
    int n,i;
    int am,duong;
    cout<<"So phan tu cua mang: ";
    cin>>n;
    for (i=0; i<n; i++)
    {
        cout<<"\nSo hang thu "<<i+1<<": ";
        am = -(rand()%50);
        duong = rand()%50+1;
        int so = am+duong;
        a[i].setSoNguyen(so);
        a[i].inSoNguyen();
    }

    for (i=0; i<n; i++)
    {
        if (a[i].kiemTraSoNguyen(a[i])==true)
        {
            a[i].inSoLuongSoNguyenDuongDaTao();
        }
    }
    cout<<"\nSo luong so nguyen duong da tao la: ";
    a[i].inSoLuongSoNguyenDuongDaTao();

	system("PAUSE");
	return EXIT_SUCCESS;
}

// du lieu mang tinh chat minh hoa de chay thu chuong trinh
// sinh vien co the thay doi du lieu ve so luong san pham
// va gia thanh de kiem tra chuong trinh co chay dung khong
// sinh tu dinh nghia luong tien mang theo:
// TIEN1, TIEN2, TIEN3 de chay thu chuong trinh

const int SO_SAN_PHAM = 10;
std::string TEN_SAN_PHAM[] = {"Cocacola x24", "Tao Lang Son", "Bap Cai", 
                              "Snack Oishi 150GR", "Rau Muong", "Thit Lon Than", 
                              "Nuoc Mam Chai 750ML", "Trung Vit x24", 
                              "Gao Tam Tau", "Nuoc Rua Bat 500ML"};

const int SO_LUONG_SAN_PHAM[] = {2, 10, 4, 
                                 5, 3, 4, 
                                 2, 2, 
                                 3, 2};
// don vi nghin dong. khi IN RA HOA DON can quy doi sang don vi dong (x1000)
const double GIA_THANH_SAN_PHAM[] = {99.5, 5.7, 12.6, 
                                     10.5, 9.7, 50.6,
                                     30.2, 57.9,
                                     22.3, 25.6};
/*
// du lieu cho Bai Tap 2
const bool THIET_YEU[SO_SAN_PHAM] = {true, true, true, 
                                     false, true, false, 
                                     true, true, 
                                     false, false};

// du lieu cho Bai Tap 3
double SO_LUONG_SAN_PHAM_BAI3[] = {2.0, 3.5, 2.5, 
                                         5.0, 1.2, 2.7, 
                                         2.0, 2.0, 
                                         6.0, 2.0};
// don vi nghin dong. khi IN RA HOA DON can quy doi sang don vi dong (x1000)
double GIA_THANH_SAN_PHAM_BAI3[] = {99.5, 15.7, 19.6, 
                                          10.5, 20.3, 75.6,
                                          30.2, 57.9,
                                          12.2, 25.6};
enum KIEU {CHIEC, KGS};
const enum KIEU KIEU_SAN_PHAM[] = {CHIEC, KGS, KGS, 
                                   CHIEC, KGS, KGS, 
                                   CHIEC, CHIEC, 
                                   KGS, CHIEC};
*/

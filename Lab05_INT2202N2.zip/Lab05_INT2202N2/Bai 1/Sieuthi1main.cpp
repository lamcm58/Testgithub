#include <cstdlib>
#include <iostream>
#include "DuLieu.h"
#include "SieuThi.h"

using namespace std;

// luu y trong file DuLieu.h cac mang deu la hang
// nen sao chep sang mang khac de xu ly

int main() {
	// Tien don vi nghin dong
	double Tien = 100;
    int muaHangTheoCach = 1;

	int SoLuongSP[SO_SAN_PHAM];
	double GiaThanhSP[SO_SAN_PHAM];
	int SoLuongSPSeMua[SO_SAN_PHAM];
	int soSPSeMua;

    // nen co mot mang luu gia tri tung san pham
    // de tranh viec phai tinh nhieu lan
    double GiaTriSP[SO_SAN_PHAM];

	if (duTienKo(Tien, SoLuongSP, GiaThanhSP, SO_SAN_PHAM))
	{
		cout << "du tien mua tat ca. Yoohooooo!!!\n";
		inHoaDon(Tien);
	}
	else
    {
		// trong truong hop khong du tien mua hang
		// can mot bien dem so luong mat hang se mua
		// va mot bien mang de luu so luong moi mat hang se mua tuong ung
		// khong su dung duoc bien mang SO_LUONG_SAN_PHAM
		if (muaHangTheoCach == 1)
		{
			cout << "1. Tat ca cac mat hang co gia thanh tren mot san pham thap nhat\n";
			SapXepSP(SoLuongSP, GiaThanhSP, GiaTriSP);
			muare(Tien);
			cout << "Danh sach hang hoa du kien mua.\n";
			inHoaDon(Tien);
		}
		else if (muaHangTheoCach == 2)
		{
			cout << "2. Tat ca cac mat hang co gia tri san pham thap nhat\n";
			SapXepSP(SoLuongSP, GiaThanhSP, GiaTriSP);
			muasoluong(Tien);
			cout << "Danh sach hang hoa du kien mua.\n";
			inHoaDon(Tien);
		}	
	}

	system("PAUSE");
	return EXIT_SUCCESS;
}


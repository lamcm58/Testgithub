#include<iostream>
#include<iomanip>
#include<cstdlib>
#include"SieuThi.h"
#include"Dulieu.h"
using namespace std;

void doichostring(string a, string b)
{
     string c;
     c=a;
     a=b;
     b=c;
}

void doicho(double a,double b)
{
     double c;
     c=a;
     a=b;
     b=c;
}

double GiaTriSP(double SoLuongSP, double GiaThanhSP)
{
    double Giatri;
    Giatri = SoLuongSP*GiaThanhSP;   
	return Giatri;
}

void GiaTriSP(int SoLuongSP[], double GiaThanhSP[], double GiaTriSP[], int soSP)
{
     
}

bool duTienKo(double Tien, int SoLuongSP[], double GiaThanhSP[], int soSP)
{
    int i;
    double tong=0.0;
    for (i=1;i<=soSP;i++)
    {
        tong+=(SoLuongSP[i]*GiaThanhSP[i]);
    }
    if (tong>Tien) return false; 
	else return true;
}

void SapXepSP(int SoLuong[], double GiaThanhSP[], double GiaTriSP[])
{
     int i,j;     
     for(i=0;i<10;i++)
     for(j=i+1;j<=10;j++)
     {
         GiaTriSP[i]=SoLuong[i]*GiaThanhSP[i];                
         if (GiaThanhSP[i]>GiaThanhSP[j])
         {
             doicho(SoLuong[i],SoLuong[j]);
             doicho(GiaThanhSP[i],GiaThanhSP[j]);
             doicho(GiaTriSP[i],GiaTriSP[j]);
         }
     }
                                                        
}

void muare(double Tien)
{
	int i, j, soluongle;
	double sl[10], gt[10], min, tong, thua;
	string tensp[10];
	for (i=0;i<10;i++)
	{
        tensp[i]=TEN_SAN_PHAM[i];
    }
	for(i=0; i<9; i++)
	{
		for(j=0; j<10-1-i; j++)
		{
			if(gt[j]>gt[j+1])
			{
		
				doicho(gt[j], gt[j+1]);
				doicho(sl[j], sl[j+1]);
				doichostring(tensp[j], tensp[j+1]);
			}
		}
	}

	tong=0;
	i=0;
	
	while(1)
	{
		
		tong=tong + sl[i]*gt[i];
		if(tong<Tien)
		{
			i++;
		}
		else 
		{
			tong=tong-sl[i]*gt[i];
			i--;
			break;
			
			
		}
	}
	cout<<endl;
	
	cout<<"Tong so tien da mua: "<<tong<<endl;
	
	thua=Tien-tong;
	soluongle=0;
	
	while(thua>=gt[i+1])
	{
		soluongle=soluongle+1;
		thua=thua-gt[i+1];
	}
	
	for(j=0; j<=i; j++)
	{
		cout<<setw(20)<<tensp[j]<<setw(10)<<sl[j]<<setw(10)<<gt[j]*1000<<endl;
	}
	if(soluongle>=1)
	{
		cout<<setw(20)<<tensp[i+1]<<setw(10)<<soluongle<<setw(10)<<gt[i+1]*1000<<endl;
	}
	cout<<"Ban thua so tien la: "<<thua*1000<<endl;
}

void muasoluong(double Tien)
{
	int i, j, soluongle;
	double sl[10], gt[10], tong, thua, tiensp[10];
	string tensp[10];
	for(i=0; i<10; i++)
	{     
        tensp[i]=TEN_SAN_PHAM[i];     
		tiensp[i]=sl[i]*gt[i];
	}
	for(i=0; i<10-1; i++)
	{
		for(j=0; j<10-i-1; j++)
		{
			if(tiensp[j]>tiensp[j+1])
			{
				doicho(tiensp[j], tiensp[j+1]);
				doicho(gt[j], gt[j+1]);
				doicho(sl[j], sl[j+1]);
				doichostring(tensp[j], tensp[j+1]);
				
			}
		}
	}
	
	tong=0;
	i=0;
	
	while(1)
	{
		
		tong=tong + tiensp[i];
		if(tong<Tien)
		{
			i++;
		}
		else 
		{
			tong=tong-sl[i]*gt[i];
			i--;
			break;	
		}
	}
	cout<<endl;
	
	cout<<"Tong so tien da mua: "<<tong<<endl;
	thua=Tien-tong;
	
	for(j=0; j<=i; j++)
	{
		cout<<setw(20)<<tensp[j]<<setw(10)<<sl[j]<<setw(10)<<gt[j]*1000<<endl;
	}
	
	cout<<"Ban thua so tien la: "<<thua*1000<<endl;
}

void inHoaDon(double Tien)
{
     int i;
     double sl[10],gt[10],Tong=0;
     string tensp[10];
     for(i=0;i<10;i++)
     {
         tensp[i]=TEN_SAN_PHAM[i];             
         Tong+=sl[i]*gt[i];  
     }
     if (Tong<=Tien)
     {
         for(i=0;i<10;i++)
         {
             cout<<setw(20)<<tensp[i]<<setw(10)<<setw(10)<<gt[i]*1000<<endl;
         }
     }
     else if (Tong>Tien)
     {
          muare(Tien);
          muasoluong(Tien);
     }                                            
}

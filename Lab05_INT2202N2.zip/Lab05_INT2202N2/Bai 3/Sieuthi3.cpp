#include<iostream>
#include<iomanip>
#include<cstdlib>
#include"SieuThi3.h"
#include"Dulieu3.h"
using namespace std;

void doichostring(string a, string b)
{
     string c;
     c=a;
     a=b;
     b=c;
}

void doicho(double a,double b)
{
     double c;
     c=a;
     a=b;
     b=c;
}

double GiaTriSP(double SoLuongSP, double GiaThanhSP)
{
    double Giatri;
    Giatri = SoLuongSP*GiaThanhSP;   
	return Giatri;
}

void GiaTriSP(int SoLuongSP[], double GiaThanhSP[], double GiaTriSP[], int soSP)
{
     
}

bool duTienKo(double Tien, int SoLuongSP[], double GiaThanhSP[], int soSP)
{
    int i;
    double tong=0.0;
    for (i=1;i<=soSP;i++)
    {
        tong+=(SoLuongSP[i]*GiaThanhSP[i]);
    }
    if (tong>Tien) return false; 
	else return true;
}

void SapXepSP(int SoLuong[], double GiaThanhSP[], double GiaTriSP[])
{
     int i,j;     
     for(i=0;i<10;i++)
     for(j=i+1;j<=10;j++)
     {
         GiaTriSP[i]=SoLuong[i]*GiaThanhSP[i];                
         if (GiaThanhSP[i]>GiaThanhSP[j])
         {
             doicho(SoLuong[i],SoLuong[j]);
             doicho(GiaThanhSP[i],GiaThanhSP[j]);
             doicho(GiaTriSP[i],GiaTriSP[j]);
         }
     }
                                                        
}


void muathietyeutheosoluong(double Tien)
{
	cout<<"Mua san pham thiet yeu theo tong gia tri tu thap den cao"<<endl;
	int i, k, j=0;
	double sl[10], gt[10], tong, thua, tiensp[10];
	string tensp[10];
	for(i=0; i<10; i++)
	{
		if(THIET_YEU[i]== true)
		{
		
			sl[j]=SO_LUONG_SAN_PHAM_BAI3[i];
			gt[j]=GIA_THANH_SAN_PHAM_BAI3[i];
			tensp[j]=TEN_SAN_PHAM[i];
			j++;
		}
	}

	for(i=0; i<j; i++)
	{
		tiensp[i]=sl[i]*gt[i];
	}
	for(i=0; i<j-1; i++)
	{
		for(k=0; k<j-i-1; k++)
		{
			if(tiensp[k]>tiensp[k+1])
			{
				doicho(tiensp[k], tiensp[k+1]);
				doicho(gt[k], gt[k+1]);
				doicho(sl[k], sl[k+1]);
				doichostring(tensp[k], tensp[k+1]);
				
			}
		}
	}
	
	for(i=0; i<10; i++)
	{
		if(THIET_YEU[i]== false)
		{
		
			sl[j]=SO_LUONG_SAN_PHAM_BAI3[i];
			gt[j]=GIA_THANH_SAN_PHAM_BAI3[i];
			tensp[j]=TEN_SAN_PHAM[i];
			j++;
		}

	}
	
	
	tong=0;
	i=0;
	
	while(1)
	{
		
		tong=tong + sl[i]*gt[i];
		if(tong<Tien)
		{
			i++;
		}
		else 
		{
			tong=tong-sl[i]*gt[i];
			i--;
			break;
			
			
		}
	}
	cout<<endl;
	
	cout<<"Tong so tien da mua: "<<tong*1000<<endl;
	
	
	thua=Tien-tong;
	
	for(j=0; j<=i; j++)
	{
		cout<<setw(20)<<tensp[j]<<setw(10)<<sl[j]<<setw(10)<<gt[j]<<endl;
	}
		cout<<"Ban thua so tien la: "<<thua*1000<<endl;
}

void inHoaDon(double Tien)
{
     int i;
     double sl[10],gt[10],Tong=0;
     string tensp[10];
     for(i=0;i<10;i++)
     {
         tensp[i]=TEN_SAN_PHAM[i];             
         Tong+=sl[i]*gt[i];  
     }
     if (Tong<=Tien)
     {
         for(i=0;i<10;i++)
         {
             cout<<setw(20)<<tensp[i]<<setw(10)<<setw(10)<<gt[i]*1000<<endl;
         }
     }
     else if (Tong>Tien)
     {
          muathietyeutheosoluong(Tien);
     }                                            
}

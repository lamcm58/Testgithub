#include <string>

// gia thanh chua bao gom thue VAT 10%
const double VAT = 0.1;

// tinh gia tri san pham dua tren so luong & gia thanh moi san pham
double GiaTriSP(int SoLuongSP, double GiaThanhSP);

// tinh gia tri san pham cua tung cac san pham trong dach sach mua hang du kien
void GiaTriSP(int SoLuongSP[], double GiaThanhSP[], double GiaTriSP[], int soSP);

// kiem tra co du tien de mua toan bo danh sach hang hoa khong
bool duTienKo(double Tien, int SoLuongSP[], double GiaThanhSP[], int soSP);

// sap xep danh sach san pham theo gia thanh hoac gia tri
// de giai quyet 2 phuong an trong bai tap 1
void SapXepSP(int SoLuong[], double GiaThanhSP[], double GiaTriSP[]);

// quyet dinh mua nhung san pham nao, so luong bao nhieu
//void muare(double Tien);

//void muasoluong(double Tien);

void muathietyeutheosoluong(double Tien);

void inHoaDon(double Tien);

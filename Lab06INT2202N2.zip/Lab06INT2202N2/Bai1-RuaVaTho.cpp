#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <windows.h>
#include <ctime>

using namespace std;

int Ruachay(int vitri1);
int Thochay(int vitri2);

int main()
{
    int i;
    for (i=0;i<3;i++)
    {
        Sleep(1000);
        system("cls");
        cout<<3-i;
    }
    Sleep(1000);
    system("cls");
    cout<<"Bat dau!";
    
    srand(time(0)); 
    
    int Rua, Tho;
    Rua=0;
    Tho=0;
    while (true)
    {
        Rua=Ruachay(Rua);
        Tho=Thochay(Tho);
        Sleep(50);
        system("cls");
        cout<<"\nXP"<<setw(Rua+1)<<"R"<<setw(71-Rua)<<"D"<<endl;
        cout<<"XP"<<setw(Tho+1)<<"T"<<setw(71-Tho)<<"D"<<endl;
        
        if (Rua>=70)
        {
            cout<<"Rua thang!!"<<endl;
            break;
        }
        if (Tho>=70)
        {
            cout<<"Tho thang!!"<<endl;
            break;
        }
    }
    system("pause");
}

int Ruachay(int vitri1)
{
    int a;
    a=rand()%100;
    if (a<20)
    {
        vitri1-=6;
    }
    if (a>=20&&a<70)
    {
        vitri1+=3;
    }
    if (a>=70&&a<100)
    {
        vitri1+=1;
    }
    if (vitri1>=70)
    {
        vitri1=70;
    }
    if (vitri1<0)
    {
        vitri1=0; 
    }
    return vitri1;
}

int Thochay(int vitri2)
{
    int a;
    a=rand()%100;
    if (a<20)
    {
        vitri2-=6;
    }
    if (a>=20&&a<40)
    {
        vitri2+=9;
    }
    if (a>=40&&a<50)
    {
        vitri2-=12;
    }
    if (a>=50&&a<80)
    {
        vitri2+=1;
    }
    if (a>=80&&a<100)
    {
        vitri2-=2;
    }
    if (vitri2>=70)
    {
        vitri2=70;
    }
    if (vitri2<0)
    {
        vitri2=0;
    }
    return vitri2;
}                                                                                                                                             

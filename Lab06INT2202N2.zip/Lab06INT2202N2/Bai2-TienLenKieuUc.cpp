#include<iostream>
#include<iomanip>
#include<time.h>

using namespace std;


string inquanbai(int khoa)
{
       std::string so, chat, b;
       if (khoa<0) return b=" ";
       if (khoa/4==0) so="2";
       if (khoa/4==1) so="3";
       if (khoa/4==2) so="4";
       if (khoa/4==3) so="5";
       if (khoa/4==4) so="6";
       if (khoa/4==5) so="7";
       if (khoa/4==6) so="8";
       if (khoa/4==7) so="9";
       if (khoa/4==8) so="10";
       if (khoa/4==9) so="J";
       if (khoa/4==10) so="Q";
       if (khoa/4==11) so="K";
       if (khoa/4==12) so="A";
       
       if (khoa%4==0) chat=6;
       if (khoa%4==1) chat=5;
       if (khoa%4==2) chat=4;
       if (khoa%4==3) chat=3;
       
       return so+chat;
}

bool uutien(int khoa1, int khoa2)
{
    if (khoa1>khoa2) return true;
    else return false;
}

void doicho(int &a, int &b)
{
    int tam;
    tam = a;
    a = b;
    b = tam;
}
 
void traobai(int *Bobai)
{
    int i;
    for (i=0; i<52; i++)
    {
        doicho (Bobai[i], Bobai[rand()%52]);
    }
}

void chiabai(int *BoBai, int **boBaiNguoiChoi)
{
    int i,j;
    for (i=0; i<4;i++)
    for (j=0;j<13;j++)
    {
        boBaiNguoiChoi[i][j]=BoBai[i*j];
    }
} 
void inbobai(int BoBai[])
{
    cout<<setw(15)<<"Nguoichoi1"<<setw(15)<<"Nguoichoi2"<<setw(15)<<"Nguoichoi3"<<setw(15)<<"Nguoichoi4";
    cout<<"\n";
    int j,k;
    for (j=0; j<13; j++)
    {
        for (k=0; k<4;k++)
        cout<<setw(15)<<inquanbai(BoBai[j*4+k]);
        cout<<"\n";
    }
}
int main()
{
    int i,j;
    srand(time(0));
    int BoBai[52];
    for (i=0; i<52; i++)
    {
        BoBai[i]=i;
    }
    traobai(BoBai);
    cout<<"Chia bai cho 4 nguoi choi \n";
    inbobai(BoBai);
    system("pause");
    system("cls");
    for (i=0;i<52; i++)
    {
        if (BoBai[i]==0)
        {
            if (i%4==0) cout<<"Nguoi choi 1 danh "<<inquanbai(BoBai[i])<<endl;
            if (i%4==1) cout<<"Nguoi choi 2 danh "<<inquanbai(BoBai[i])<<endl;
            if (i%4==2) cout<<"Nguoi choi 3 danh "<<inquanbai(BoBai[i])<<endl;
            if (i%4==3) cout<<"Nguoi choi 4 danh "<<inquanbai(BoBai[i])<<endl;
            BoBai[i]=-1;
            inbobai(BoBai);
        }
    }
    system("pause");
}               
                             

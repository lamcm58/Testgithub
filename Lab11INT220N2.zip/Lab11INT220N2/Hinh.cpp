#include<iostream>
#include<cstdlib>
#include<cmath>
using namespace std;

class Shape
{
      public:
          Shape() : Dientich(-1), Chuvi(-1){}
          ~Shape(){}
             
          double getDienTich() const
          {
              return Dientich;
          }
          double getChuVi() const
          {
              return Chuvi;
          }
          void draw()
          {
               cout<<"Ve hinh";
          }     
      protected:
          double Dientich;
          double Chuvi;
};

class Triangle: public Shape
{
      public:
          Triangle(): a(5), b(8), c(9){}
          ~Triangle(){}
          
          void setTriangle(double a,double b,double c)
          {
               this->a=a;
               this->b=b;
               this->c=c;
          }
          double getChuVi() const
          {
               double P;
               P=a+b+c;  
               return P;
          }
          double getDienTich() const
          {
               double p,S;
               p=(a+b+c)/2;
               S=sqrt(p*(p-a)*(p-b)*(p-c));
               return S;
          }
          
          void draw()
          {
               cout<<"Ve hinh tam giac voi do dai ba canh la a, b, c"<<endl;
          }                      
      protected:
          double a;
          double b;
          double c;                                     
};

class Rectangle: public Shape
{
      public:
          Rectangle(): a(17), b(6){}
          ~Rectangle(){}
          
          void setRectangle(double a, double b)
          {
               this->a=a;
               this->b=b;
          }            
          double getChuVi() const
          {
               double P;
               P=2*(a+b);
               return P;
          }
          double getDienTich() const
          {
               double S;
               S=a*b;
               return S;
          }
          
          void draw()
          {
               cout<<"Ve hinh chu nhat voi chieu dai length va chieu rong width"<<endl;
          }     
      protected:
          double a;
          double b;
};      

class Square: public Rectangle
{
      public:
          Square():a(7){}
          ~Square(){}
          
          void setSquare(double a)
          {
          	   this->a=a;
          }
          double getChuVi() const
          {
          	   return (4*a);
          }
          double getDienTich() const
          {
          	   return (a*a);
          }
          
          void draw()
          {
               cout<<"Ve hinh vuong chieu dai canh la length"<<endl;
          }    
      protected:
          double a;
};   

class Circle: public Shape
{
      public:
          Circle() : r(4){}
          ~Circle(){}
          
          void setCircle(double r)
          {
               this->r=r;
          }   
          double getChuVi() const
          {
              return (2*r*3.14);	 	
          }
          double getDienTich() const
          {
          	  return (r*r*3.14);	
          }
          void draw()
          {
          	   cout<<"Ve hinh tron voi ban kinh radius"<<endl;
          }
      protected:
          double r;
};                    

int main()
{
	Triangle tamgiac;
	tamgiac.draw();
	cout<<"Chu vi tam giac = "<<tamgiac.getChuVi()<<endl;
	cout<<"Dien tich tam giac = "<<tamgiac.getDienTich()<<endl<<endl;
	
	Rectangle chunhat;
	chunhat.draw();
	cout<<"Chu vi hinh chu nhat = "<<chunhat.getChuVi()<<endl;
	cout<<"Dien tich hinh chu nhat = "<<chunhat.getDienTich()<<endl<<endl;
	
	Square vuong;
	vuong.draw();
	cout<<"Chu vi hinh vuong = "<<vuong.getChuVi()<<endl;
	cout<<"Dien tich hinh vuong = "<<vuong.getDienTich()<<endl<<endl;
	
	Circle tron;
	tron.draw();
	cout<<"Chu vi hinh tron = "<<tron.getChuVi()<<endl;
	cout<<"Dien tich hinh tron = "<<tron.getDienTich()<<endl<<endl;
	
	system("pause");
	return EXIT_SUCCESS;
}
